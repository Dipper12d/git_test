import csv
import matplotlib.pyplot as plt
import numpy as np

# initialize the columns
year = []
dividends = []
interest = []
others = []
rent = []
royalties = []
trade_income = []
dividends2 = []
interest2 = []
others2 = []
rent2 = []
royalties2 = []
tradinc2 = []


# open the file
openfile = open("incometypesg_datatype.csv")
csvreader = csv.reader(openfile)
next(csvreader)  # skip title row
# append row in the list
for row in csvreader:
    # row is a list
    year.append(row[0])
    dividends.append(row[1])
    interest.append(row[2])
    others.append(row[3])
    rent.append(row[4])
    royalties.append(row[5])
    trade_income.append(row[6])

# create new lists of range 2011 to 2016
for ix in range(3, 9, 1):
    dividends2.append(year[ix])
    interest2.append(year[ix])
    others2.append(year[ix])
    rent2.append(year[ix])
    royalties2.append(year[ix])
    tradinc2.append(year[ix])


def dispmenu():  # The displayed menu
    print("=" * 40)
    print("Income Calculator-Choose what to calculate")
    print("A-Information for a year")
    print("B-Maximum, minimum and mean values from 2011 to 2016")
    print("C-Find 30 percent change between years ")
    print("D-Make plots")
    print("Q-Quit")
    print("=" * 40)


def dispinfo():
    inputyear = int(input("Please input which year you want information for:"))
    if inputyear >= 2019:
        print("No information on the given year.")
    else:
        print(f"For year {year[inputyear-2007]},")
        print(f"Dividends is {dividends[inputyear-2007]}")
        print(f"Interest is {interest[inputyear-2007]}")
        print(f"Other types is {others[inputyear-2007]}")
        print(f"Rent is {rent[inputyear-2007]}")
        print(f"Royalties is {royalties[inputyear-2007]}")
        print(f"Trade income is {trade_income[inputyear-2007]}")


def meanminmax():
    print("Choose either:")
    print("A-Mean")
    print("B-Maximum and minimum")
    option = input("Please choose:")
    if option == "A" or option == "a":
        meancalc()
    elif option == "B" or option == "b":
        minmaxcalc()


def meancalc():
    print("Please choose an income type")
    print("1-Dividends")
    print("2-Interest")
    print("3-Other types")
    print("4-Rent")
    print("5-Royalties")
    print("6-Trade income")
    chooserow = input("Please select 1,2,3,4,5 or 6:")
    if chooserow == "1":
        sum1 = sum(dividends2)
        output1 = sum1 / 6
    elif chooserow == "2":
        sum1 = sum(interest2)
        output1 = sum1 / 6
    elif chooserow == "3":
        sum1 = sum(others2)
        output1 = sum1 / 6
    elif chooserow == "4":
        sum1 = sum(rent2)
        output1 = sum1 / 6
    elif chooserow == "5":
        sum1 = sum(royalties2)
        output1 = sum1 / 6
    elif chooserow == "6":
        sum1 = sum(tradinc2)
        output1 = sum1 / 6
    print(f"The mean value is {output1}")


def minmaxcalc():
    print("Please choose an income type")
    print("1-Dividends")
    print("2-Interest")
    print("3-Other types")
    print("4-Rent")
    print("5-Royalties")
    print("6-Trade income")
    chooserow = input("Please select 1,2,3,4,5 or 6:")
    if chooserow == "1":
        print(
            f"The maximum is {max(dividends2)} in {year[dividends.index(max(dividends2))]} and minimum is {min(dividends2)} in {year[dividends.index(min(dividends2))]}."
        )
    elif chooserow == "2":
        print(
            f"The maximum is {max(interest2)} in {year[interest.index(max(interest2))]} and minimum is {min(interest2)} in {year[interest.index(min(interest2))]}."
        )
    elif chooserow == "3":
        print(
            f"The maximum is {max(others2)} in {year[others.index(max(others2))]} and minimum is {min(others2)} in {year[others.index(min(others2))]}."
        )
    elif chooserow == "4":
        print(
            f"The maximum is {max(rent2)} in {year[rent.index(max(rent2))]} and minimum is {min(rent2)} in {year[rent.index(min(rent2))]}."
        )
    elif chooserow == "5":
        print(
            f"The maximum is {max(royalties2)} in {year[royalties.index(royalties2)]} and minimum is {min(royalties2)} in {year[royalties.index(min(royalties2))]}."
        )
    else:
        print(
            f"The maximum is {max(tradinc2)} in {year[trade_income.index(tradinc2)]} and minimum is {min(tradinc2)} in {year[trade_income.index(min(tradinc2))]}."
        )


def percent30():
    print("Please choose an income type")
    print("1-Dividends")
    print("2-Interest")
    print("3-Other types")
    print("4-Rent")
    print("5-Royalties")
    print("6-Trade income")
    chooserow2 = input("Please select 1,2,3,4,5 or 6:")
    print(
        "In this category, values that changes by at least 30 percent compared to the previous year are:"
    )
    if chooserow2 == "1":
        for ik in range(1, 11):
            if ((int(dividends[ik])) / (int(dividends[ik - 1]))) * 100 >= 130 or (
                (int(dividends[ik])) / (int(dividends[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {dividends[ik]} in {year[ik]} to {dividends[ik - 1]} in {year[ik-1]}"
                )
            else:
                continue
    elif chooserow2 == "2":
        for ik in range(1, 11):
            if ((int(interest[ik])) / (int(interest[ik - 1]))) * 100 >= 130 or (
                (int(interest[ik])) / (int(interest[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {interest[ik]} in {year[ik]} to {interest[ik - 1]} in {year[ik-1]}"
                )
            else:
                continue
    elif chooserow2 == "3":
        for ik in range(1, 11):
            if ((int(others[ik])) / (int(others[ik - 1]))) * 100 >= 130 or (
                (int(others[ik])) / (int(others[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {others[ik]} in {year[ik]} to {others[ik - 1]} in {year[ik-1]}"
                )
            else:
                continue
    elif chooserow2 == "4":
        for ik in range(1, 11):
            if ((int(rent[ik])) / (int(rent[ik - 1]))) * 100 >= 130 or (
                (int(rent[ik])) / (int(rent[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {rent[ik]} in {year[ik]} to {rent[ik - 1]} in {year[ik-1]}"
                )
            else:
                continue
    elif chooserow2 == "1":
        for ik in range(1, 11):
            if ((int(royalties[ik])) / (int(royalties[ik - 1]))) * 100 >= 130 or (
                (int(royalties[ik])) / (int(royalties[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {royalties[ik]} in {year[ik]} to {royalties[ik - 1]} in {year[ik-1]}"
                )
            else:
                continue
    elif chooserow2 == "1":
        for ik in range(1, 11):
            if ((int(trade_income[ik])) / (int(trade_income[ik - 1]))) * 100 >= 130 or (
                (int(trade_income[ik])) / (int(trade_income[ik - 1]))
            ) * 100 <= 70:
                print(
                    f"From {trade_income[ik]} in {year[ik]} to {trade_income[ik - 1] in {year[ik-1]}}"
                )
            else:
                continue
    print("There are no more values with such a change.")


def plots():
    plt.plot(year, dividends, label="Dividends")
    plt.plot(year, trade_income, label="Trade income")
    plt.xlabel("x - axis")
    # naming the y axis
    plt.ylabel("y - axis")
    # giving a title to my graph
    plt.title("Dividends and trade income from 2007 to 2018")

    # show a legend on the plot
    plt.legend()

    # function to show the plot
    plt.show()


def plots2():
    barWidth = 0.25
    fig = plt.subplots(figsize=(12, 8))
    br1 = np.arange(len(interest))
    br2 = [x + barWidth for x in br1]
    plt.bar(
        br1, interest, color="r", width=barWidth, edgecolor="grey", label="Interest"
    )
    plt.bar(br2, rent, color="g", width=barWidth, edgecolor="grey", label="Rent")
    plt.xlabel("Years", fontweight="bold", fontsize=15)
    plt.ylabel("X-axis", fontweight="bold", fontsize=15)
    plt.xticks(
        [r + barWidth for r in range(len(interest) - 1)],
        [
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
        ],
    )

    plt.legend()
    plt.show()


doagain = False
while doagain := True:
    dispmenu()
    selec = input("Please choose A,B,C,D or Q:")
    if selec == "A" or selec == "a":
        dispinfo()
    elif selec == "B" or selec == "b":
        minmaxcalc
    elif selec == "C" or selec == "c":
        percent30()
    elif selec == "D" or selec == "d":
        plots()
    elif selec == "Q" or selec == "q":
        print("Thank you for using the system")
        do_again = False
        break
    else:
        print("Invalid selection, Try again.")

plots2()
